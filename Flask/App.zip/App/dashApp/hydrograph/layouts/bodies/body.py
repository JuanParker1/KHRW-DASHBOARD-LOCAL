from App.dashApp.hydrograph.layouts.bodies.body_tab1 import *
from App.dashApp.hydrograph.layouts.bodies.body_tab2 import *
from App.dashApp.hydrograph.layouts.bodies.body_tab3 import *
