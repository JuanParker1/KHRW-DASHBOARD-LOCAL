from App.dashApp.hydrograph.layouts.footers.footer_tab1 import *
from App.dashApp.hydrograph.layouts.footers.footer_tab2 import *
from App.dashApp.hydrograph.layouts.footers.footer_tab3 import *