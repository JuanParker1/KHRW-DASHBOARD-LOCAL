from App.dashApp.hydrograph.layouts.tabs.tab1 import *
from App.dashApp.hydrograph.layouts.tabs.tab2 import *
from App.dashApp.hydrograph.layouts.tabs.tab3 import *