from layouts.footers.footer_tab1 import *
from layouts.footers.footer_tab2 import *
from layouts.footers.footer_tab3 import *
