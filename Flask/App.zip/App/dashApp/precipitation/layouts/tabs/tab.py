from layouts.tabs.tab1 import *
from layouts.tabs.tab2 import *
from layouts.tabs.tab3 import *
