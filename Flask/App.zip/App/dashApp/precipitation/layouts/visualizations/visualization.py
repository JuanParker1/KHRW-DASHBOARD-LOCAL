from layouts.visualizations.visualization_tab1 import *
from layouts.visualizations.visualization_tab2 import *
from layouts.visualizations.visualization_tab3 import *
