from callbacks.callback_tab1 import *
from callbacks.callback_tab2 import *
from callbacks.callback_tab3 import *
