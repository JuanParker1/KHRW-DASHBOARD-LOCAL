from App.dashApp.isotope_analysis.callbacks.callback_tab1 import isotope_analysis_callback_tab1

def isotope_analysis_callback(app):
    isotope_analysis_callback_tab1(app=app)
    