from App.dashApp.isotope_analysis.layouts.sidebars.sidebar_tab1 import *
