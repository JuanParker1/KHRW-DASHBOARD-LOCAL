from App.dashApp.isotope_analysis.layouts.visualizations.visualization_tab1 import *
from App.dashApp.isotope_analysis.layouts.visualizations.visualization_tab2 import *
from App.dashApp.isotope_analysis.layouts.visualizations.visualization_tab3 import *
