from App.dashApp.isotope_analysis.layouts.bodies.body_tab1 import *
