from App.dashApp.chemograph.layouts.tabs.tab1 import *
from App.dashApp.chemograph.layouts.tabs.tab2 import *
from App.dashApp.chemograph.layouts.tabs.tab3 import *