from App.dashApp.chemograph.layouts.bodies.body_tab1 import *
from App.dashApp.chemograph.layouts.bodies.body_tab2 import *
from App.dashApp.chemograph.layouts.bodies.body_tab3 import *
